clc; clear; close all;
data = csvread('composite_signal.csv');
t = data(:,1);  
signal = data(:,2); 

figure % grafiki
plot(t, signal)
xlabel('Xronos se s')
ylabel('platos')
title('sintheto sima')
grid on

%ipologizo xroniko bima
dt = t(2) - t(1);  
fs = 1/dt  % sixnotita deigmatolipsias
N = length(signal); % plithos deigmaton
f = (-N/2 : N/2-1)*(fs/N); %dimiourgia axona
fft_signal = fft(signal); %ipologismos fft
fft_signalshift = fftshift(fft_signal); %tarrasso to sto kentro
magnitude = abs(fft_signalshift); %metro fasmatos
%grafiki fasmatos:
figure
plot(f, magnitude)
xlabel('Frq (Hz)')
ylabel('X(f) se apoliti')
title('platos fasmatos')
grid on