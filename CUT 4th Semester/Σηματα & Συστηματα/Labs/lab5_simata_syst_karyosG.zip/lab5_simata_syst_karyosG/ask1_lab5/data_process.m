function [avg, positives] = data_process(data)
    avg = mean(data);
    positives = data(data > 0);
    if isempty(positives)
        disp('den exei thetikous arithmous');
    end
end