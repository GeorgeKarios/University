clc;clear;

data = [-1,3,4,10,5,6,-1,-2,-9,3,4,-5,6,7];
[avg, positives] = data_process(data);
disp(['mesi timi einai ', num2str(avg)]);
disp('oi thetikoi arithmoi');
disp(positives);