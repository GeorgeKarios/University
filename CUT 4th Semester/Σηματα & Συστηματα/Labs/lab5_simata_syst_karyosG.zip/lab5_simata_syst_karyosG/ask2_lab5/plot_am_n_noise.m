function plot_am_n_noise(t, x_total, m_t, x_modulated)
    figure;
    
    subplot(3,1,1);
    plot(t, x_total, 'k', 'LineWidth', 1.5);
    grid on;
    xlabel('ora se s');
    ylabel('platos');
    title('arxiko sima(n=4)');
    
    subplot(3,1,2);
    plot(t, m_t, 'LineWidth', 1.5);
    grid on;
    xlabel('ora');
    ylabel('paltos');
    title('diamorfotis platous m(t)');
    
    subplot(3,1,3);
    plot(t, x_modulated, 'LineWidth', 1.5);
    grid on;
    xlabel('ora');
    ylabel('platos');
    title('tropopoiimeno sima');
    
    % Gaussian ixos
    noise = randn(size(t));
    x_noisy = x_total + noise;
    
    figure;
    plot(t, x_noisy, 'LineWidth', 1.2);
    grid on;
    xlabel('xronos');
    ylabel('platos');
    title('teliko sima me Gaussian thorivo');
    end
