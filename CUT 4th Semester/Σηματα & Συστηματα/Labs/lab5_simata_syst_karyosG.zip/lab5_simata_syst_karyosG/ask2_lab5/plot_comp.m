function plot_comp(t, components, x_total, n)
    figure;
    for k = 1:n
        subplot(n+1, 1, k);
        plot(t, components(k,:), 'LineWidth', 1.5);
        grid on;
        xlabel('ora:');
        ylabel('platos');
        title(['sinistosa k = ', num2str(k)]);
    end
    subplot(n+1, 1, n+1);
    plot(t, x_total, 'k', 'LineWidth', 1.6);
    grid on;
    xlabel('ora se s');
    ylabel('platos');
    title(['teliko sima n= ', num2str(n)]);
    end
