clc;clear;close all;
%% Lab 5 Ex 2
    fs = 1000;
    t  = 0:1/fs:2;
    n_values = [2 3 4];

    for ii = 1:length(n_values)
        n = n_values(ii);
        [components, x_total] = compute_comp(n, t);
        plot_comp(t, components, x_total, n);
    end
    n = 4;
    [~, x_total_4] = compute_comp(n, t);
    A_mod = 1;
    B_mod = 0.5;
    f_mod = 1;
    m_t = A_mod + B_mod*sin(2*pi*f_mod*t);
    x_mod = m_t .* x_total_4;
    plot_am_n_noise(t, x_total_4, m_t, x_mod);
