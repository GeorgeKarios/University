function [components, x_total] = compute_comp(n, t)
    components = zeros(n, length(t));
    x_total = zeros(size(t));
    for k = 1:n
        comp = k * sin(5*pi*k*t);
        components(k,:) = comp;
        x_total = x_total + comp;
    end
end