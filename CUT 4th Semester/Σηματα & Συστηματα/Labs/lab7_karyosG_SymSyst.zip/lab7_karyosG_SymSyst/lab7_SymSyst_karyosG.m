%LAB 6:
clc; clear; close all;
data = csvread('composite_signal.csv');
t = data(:,1);  
signal = data(:,2); 
figure % grafiki
plot(t, signal)
xlabel('Xronos se s')
ylabel('platos')
title('sintheto sima')
grid on
%ipologizo xroniko bima
dt = t(2) - t(1);  
fs=1/dt  % sixnotita deigmatolipsias
N=length(signal); % plithos deigmaton
f=(-N/2:N/2-1)*(fs/N); %dimiourgia axona
fft_signal = fft(signal); %ipologismos fft
fft_signalshift = fftshift(fft_signal); %tarrasso to sto kentro
magnitude = abs(fft_signalshift); %metro fasmatos
%grafiki fasmatos:
figure
plot(f, magnitude)
xlabel('Frq (Hz)')
ylabel('X(f) se apoliti')
title('platos fasmatos')
grid on

%LAB 7 
%Ask 1 Evresi Kyriarxon Sixnotiton
%damai vriskei  ta peaks tou fasmatos
[pks, locs] = findpeaks(magnitude, f, 'MinPeakHeight', 50);
disp('Kyriarxes sixnotites (Hz):')
disp(locs)

%Ask 2 Butterworth Filters
orders = [2 4 6 8];
fc=50; % frq apokopis se hz
Wn=fc / (fs/2);

figure %dimiourgia grafikis apokrisis
hold on
for n= orders
[b, a]=butter(n, Wn, 'low'); %butterworth
[H, w]=freqz(b, a, 1024, fs); %apokrisi frq
plot(w, abs(H), 'LineWidth', 1.5)
end
xlabel('Sixnotita (Hz)')
ylabel('H(f)(se apoliti)')
title('Apokrisi Sixnotitas Butterworth')
legend('Taxi 2','Taxi 4','Taxi 6','Taxi 8')
grid on
hold off

[b, a]=butter(4, Wn, 'low');
filtered_signal=filter(b, a, signal);

figure %graf simatos sto xrono
plot(t, filtered_signal)
xlabel('Xronos (s)')
ylabel('Platos')
title('Katharo Sima (Butterworth 4is Taksis)')
grid on
%fft katharismatos simatos
fft_filt =fft(filtered_signal);
fft_filt_shift=fftshift(fft_filt);
mag_filt=abs(fft_filt_shift);

figure %grafiki katharou simatos
plot(f, mag_filt)
xlabel('Sixnotita (Hz)')
ylabel('X(f)(se apoliti)')
title('FFT Katharou Simatos')
grid on
