#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <pthread.h>

#define BUFFER_SIZE 1024

int sockfd;

static void *send_handler(void *arg)
{
    (void)arg;

    char input[BUFFER_SIZE];
    char msg[BUFFER_SIZE + 100];

    while (1)
    {
        printf("client> ");
        fflush(stdout);

        if (fgets(input, sizeof(input), stdin) == NULL)
        {
            close(sockfd);
            pthread_exit(NULL);
        }

        input[strcspn(input, "\n")] = '\0';

        if (strcmp(input, "quit") == 0)
        {
            close(sockfd);
            pthread_exit(NULL);
        }

        snprintf(msg, sizeof(msg), "[PID %d]: %s\n", getpid(), input);

        if (send(sockfd, msg, strlen(msg), 0) < 0)
        {
            pthread_exit(NULL);
        }
    }

    return NULL;
}

static void *recv_handler(void *arg)
{
    (void)arg;

    char buffer[BUFFER_SIZE];

    while (1)
    {
        int bytes = recv(sockfd, buffer, sizeof(buffer) - 1, 0);

        if (bytes <= 0)
        {
            pthread_exit(NULL);
        }

        buffer[bytes] = '\0';

        printf("\n%s", buffer);
        printf("client> ");
        fflush(stdout);
    }

    return NULL;
}

int main(int argc, char *argv[])
{
    char *ip;
    int port;
    struct sockaddr_in server_addr;
    pthread_t send_tid, recv_tid;

    if (argc != 3)
    {
        fprintf(stderr, "Usage: %s <IP> <port>\n", argv[0]);
        return 1;
    }

    ip = argv[1];
    port = atoi(argv[2]);

    if (port <= 0)
    {
        fprintf(stderr, "Invalid port\n");
        return 1;
    }

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0)
    {
        perror("socket");
        return 1;
    }

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);

    if (inet_pton(AF_INET, ip, &server_addr.sin_addr) <= 0)
    {
        perror("inet_pton");
        close(sockfd);
        return 1;
    }

    if (connect(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
    {
        perror("connect");
        close(sockfd);
        return 1;
    }

    if (pthread_create(&send_tid, NULL, send_handler, NULL) != 0)
    {
        perror("pthread_create");
        close(sockfd);
        return 1;
    }

    if (pthread_create(&recv_tid, NULL, recv_handler, NULL) != 0)
    {
        perror("pthread_create");
        close(sockfd);
        return 1;
    }

    pthread_join(send_tid, NULL);
    pthread_join(recv_tid, NULL);

    return 0;
}