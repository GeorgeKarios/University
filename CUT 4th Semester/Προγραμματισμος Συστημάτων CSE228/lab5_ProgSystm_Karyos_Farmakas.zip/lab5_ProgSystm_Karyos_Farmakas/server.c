#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <pthread.h>

#define MAX_CLIENTS 100
#define BUFFER_SIZE 1024

typedef struct
{
    int fd;
    int port;
} client_t;

typedef struct message_node
{
    char *msg;
    struct message_node *next;
} message_node_t;

typedef struct
{
    int fd;
    int port;
} client_info_t;

client_t clients[MAX_CLIENTS];
int num_clients = 0;

message_node_t *queue_head = NULL;
message_node_t *queue_tail = NULL;

pthread_mutex_t clients_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t queue_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t queue_cond = PTHREAD_COND_INITIALIZER;

static void enqueue_message(const char *msg)
{
    message_node_t *node = (message_node_t *)malloc(sizeof(message_node_t));
    if (node == NULL)
    {
        return;
    }

    node->msg = strdup(msg);
    node->next = NULL;

    if (node->msg == NULL)
    {
        free(node);
        return;
    }

    if (queue_tail == NULL)
    {
        queue_head = node;
        queue_tail = node;
    }
    else
    {
        queue_tail->next = node;
        queue_tail = node;
    }
}

static char *dequeue_message(void)
{
    if (queue_head == NULL)
    {
        return NULL;
    }

    message_node_t *node = queue_head;
    char *msg = node->msg;

    queue_head = queue_head->next;
    if (queue_head == NULL)
    {
        queue_tail = NULL;
    }

    free(node);
    return msg;
}

static int queue_is_empty(void)
{
    return queue_head == NULL;
}

static void remove_client(int fd)
{
    int i, j;

    for (i = 0; i < num_clients; i++)
    {
        if (clients[i].fd == fd)
        {
            for (j = i; j < num_clients - 1; j++)
            {
                clients[j] = clients[j + 1];
            }
            num_clients--;
            break;
        }
    }
}

static void *broadcast_handler(void *arg)
{
    (void)arg;

    while (1)
    {
        char *msg;

        pthread_mutex_lock(&queue_mutex);

        while (queue_is_empty())
        {
            pthread_cond_wait(&queue_cond, &queue_mutex);
        }

        msg = dequeue_message();

        pthread_mutex_unlock(&queue_mutex);

        if (msg == NULL)
        {
            continue;
        }

        pthread_mutex_lock(&clients_mutex);

        for (int i = 0; i < num_clients; i++)
        {
            send(clients[i].fd, msg, strlen(msg), 0);
        }

        pthread_mutex_unlock(&clients_mutex);

        free(msg);
    }

    return NULL;
}

static void *client_handler(void *arg)
{
    client_info_t *info = (client_info_t *)arg;
    int fd = info->fd;
    int port = info->port;
    char buffer[BUFFER_SIZE];

    free(info);

    while (1)
    {
        int bytes = recv(fd, buffer, sizeof(buffer) - 1, 0);

        if (bytes <= 0)
        {
            pthread_mutex_lock(&clients_mutex);
            remove_client(fd);
            printf("Client με port number %d αποσυνδέθηκε. Συνδεδεμένοι clients: %d\n",
                   port, num_clients);
            fflush(stdout);
            pthread_mutex_unlock(&clients_mutex);

            close(fd);
            pthread_exit(NULL);
        }

        buffer[bytes] = '\0';

        pthread_mutex_lock(&queue_mutex);
        enqueue_message(buffer);
        pthread_cond_signal(&queue_cond);
        pthread_mutex_unlock(&queue_mutex);
    }
}

int main(int argc, char *argv[])
{
    int server_fd;
    int port;
    struct sockaddr_in server_addr;
    pthread_t broadcast_tid;

    if (argc != 2)
    {
        fprintf(stderr, "Usage: %s <port>\n", argv[0]);
        return 1;
    }

    port = atoi(argv[1]);
    if (port <= 0)
    {
        fprintf(stderr, "Invalid port\n");
        return 1;
    }

    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0)
    {
        perror("socket");
        return 1;
    }

    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(port);

    if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
    {
        perror("bind");
        close(server_fd);
        return 1;
    }

    if (listen(server_fd, 10) < 0)
    {
        perror("listen");
        close(server_fd);
        return 1;
    }

    if (pthread_create(&broadcast_tid, NULL, broadcast_handler, NULL) != 0)
    {
        perror("pthread_create");
        close(server_fd);
        return 1;
    }

    pthread_detach(broadcast_tid);

    while (1)
    {
        struct sockaddr_in client_addr;
        socklen_t addr_len = sizeof(client_addr);
        int client_fd;
        int client_port;
        client_info_t *info;
        pthread_t tid;

        client_fd = accept(server_fd, (struct sockaddr *)&client_addr, &addr_len);
        if (client_fd < 0)
        {
            perror("accept");
            continue;
        }

        client_port = ntohs(client_addr.sin_port);

        pthread_mutex_lock(&clients_mutex);

        if (num_clients >= MAX_CLIENTS)
        {
            pthread_mutex_unlock(&clients_mutex);
            close(client_fd);
            continue;
        }

        clients[num_clients].fd = client_fd;
        clients[num_clients].port = client_port;
        num_clients++;

        printf("Νέος client συνδέθηκε με port number %d. Συνδεδεμένοι clients: %d\n",
               client_port, num_clients);
        fflush(stdout);

        pthread_mutex_unlock(&clients_mutex);

        info = (client_info_t *)malloc(sizeof(client_info_t));
        if (info == NULL)
        {
            pthread_mutex_lock(&clients_mutex);
            remove_client(client_fd);
            num_clients = num_clients < 0 ? 0 : num_clients;
            pthread_mutex_unlock(&clients_mutex);
            close(client_fd);
            continue;
        }

        info->fd = client_fd;
        info->port = client_port;

        if (pthread_create(&tid, NULL, client_handler, info) != 0)
        {
            perror("pthread_create");
            free(info);

            pthread_mutex_lock(&clients_mutex);
            remove_client(client_fd);
            pthread_mutex_unlock(&clients_mutex);

            close(client_fd);
            continue;
        }

        pthread_detach(tid);
    }

    close(server_fd);
    return 0;
}