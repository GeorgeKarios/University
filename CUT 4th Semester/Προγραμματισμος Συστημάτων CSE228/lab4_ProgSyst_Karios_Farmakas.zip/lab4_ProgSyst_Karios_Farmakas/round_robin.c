#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <time.h>
int N;
pid_t children[100];
void child_handler(int sig)
{   printf("Child with process id %d is terminating.\n", getpid());
    fflush(stdout);
    exit(0); }

void parent_handler(int sig) {
    int i;
    for (i = 0; i < N; i++)
        kill(children[i], SIGINT);
    for (i = 0; i < N; i++)
        wait(NULL);
    printf("Parent process is terminating.\n");
    fflush(stdout);
    exit(0);
}

int main(){
    int i, status;
    printf("Give number of children: ");
    scanf("%d", &N);
    signal(SIGINT, parent_handler);
    for (i = 0; i < N; i++) {
        children[i] = fork();
        if (children[i] == 0) {
            signal(SIGINT, child_handler);
            srand(getpid());
            raise(SIGSTOP);
            while (1) {
                printf("Child %d is running %.2f\n", getpid(),
                       (double)rand() / RAND_MAX);
                fflush(stdout);
                sleep(1);
            }
        }
        waitpid(children[i], &status, WUNTRACED);
    }
    printf("Parent process created %d children with PIDs: ", N);
    for (i = 0; i < N; i++){
        printf("%d", children[i]);
        if (i < N - 1) printf(", ");
    }
    printf(".\n");
    i = 0;
    while (1){
        kill(children[i], SIGCONT);
        sleep(1);
        kill(children[i], SIGSTOP);
        i = (i + 1) % N;
    }
}
