// STYLIANOS FARMAKAS 30833
// GEORGIOS KARYOS 30738


Οδηγίες Εκτέλεσης

Μεταγλώττιση:

gcc server.c -o server
gcc client.c -o client

Εκτέλεση server:

./server <port>

Παράδειγμα:
./server 5555

Εκτέλεση client:

./client <IP> <port>

Παράδειγμα:
./client 127.0.0.1 5555

Τερματισμός client:

Πληκτρολογήστε:
quit
