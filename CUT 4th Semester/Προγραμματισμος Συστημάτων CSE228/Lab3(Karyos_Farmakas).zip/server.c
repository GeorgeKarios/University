// STYLIANOS FARMAKAS 30833
// GEORGIOS KARYOS 30738

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/select.h>

#define MAX_CLIENTS 100
#define BUFFER_SIZE 1024

int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        fprintf(stderr, "Usage: %s <port>\n", argv[0]);
        return 1;
    }

    int port = atoi(argv[1]);
    if (port <= 0)
    {
        fprintf(stderr, "Invalid port\n");
        return 1;
    }

    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0)
    {
        perror("socket");
        return 1;
    }

    int opt = 1;
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0)
    {
        perror("setsockopt");
        close(server_fd);
        return 1;
    }

    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(port);

    if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
    {
        perror("bind");
        close(server_fd);
        return 1;
    }

    if (listen(server_fd, 10) < 0)
    {
        perror("listen");
        close(server_fd);
        return 1;
    }

    int clients[MAX_CLIENTS];
    int client_ports[MAX_CLIENTS];
    for (int i = 0; i < MAX_CLIENTS; i++)
    {
        clients[i] = -1;
        client_ports[i] = -1;
    }

    printf("Server listening on port %d\n", port);

    while (1)
    {
        fd_set readfds;
        FD_ZERO(&readfds);
        FD_SET(server_fd, &readfds);

        int maxfd = server_fd;

        for (int i = 0; i < MAX_CLIENTS; i++)
        {
            if (clients[i] != -1)
            {
                FD_SET(clients[i], &readfds);
                if (clients[i] > maxfd)
                {
                    maxfd = clients[i];
                }
            }
        }

        if (select(maxfd + 1, &readfds, NULL, NULL, NULL) < 0)
        {
            perror("select");
            break;
        }

        if (FD_ISSET(server_fd, &readfds))
        {
            struct sockaddr_in client_addr;
            socklen_t client_len = sizeof(client_addr);

            int newfd = accept(server_fd, (struct sockaddr *)&client_addr, &client_len);
            if (newfd < 0)
            {
                perror("accept");
            }
            else
            {
                int placed = 0;
                for (int i = 0; i < MAX_CLIENTS; i++)
                {
                    if (clients[i] == -1)
                    {
                        clients[i] = newfd;
                        client_ports[i] = ntohs(client_addr.sin_port);
                        placed = 1;
                        break;
                    }
                }

                if (!placed)
                {
                    fprintf(stderr, "Too many clients\n");
                    close(newfd);
                }
                else
                {
                    int count = 0;
                    for (int i = 0; i < MAX_CLIENTS; i++)
                    {
                        if (clients[i] != -1)
                            count++;
                    }
                    printf("Νέος client συνδέθηκε με port number %d. Συνδεδεμένοι clients: %d\n",
                           ntohs(client_addr.sin_port), count);
                }
            }
        }

        for (int i = 0; i < MAX_CLIENTS; i++)
        {
            if (clients[i] != -1 && FD_ISSET(clients[i], &readfds))
            {
                char buffer[BUFFER_SIZE];
                int n = recv(clients[i], buffer, BUFFER_SIZE - 1, 0);

                if (n <= 0)
                {
                    int disconnected_port = client_ports[i];
                    close(clients[i]);
                    clients[i] = -1;
                    client_ports[i] = -1;

                    int count = 0;
                    for (int j = 0; j < MAX_CLIENTS; j++)
                    {
                        if (clients[j] != -1)
                            count++;
                    }

                    printf("Client με port number %d αποσυνδέθηκε. Συνδεδεμένοι clients: %d\n",
                           disconnected_port, count);
                }
                else
                {
                    buffer[n] = '\0';

                    for (int j = 0; j < MAX_CLIENTS; j++)
                    {
                        if (clients[j] != -1 && j != i)
                        {
                            send(clients[j], buffer, strlen(buffer), 0);
                        }
                    }
                }
            }
        }
    }

    close(server_fd);
    return 0;
}
