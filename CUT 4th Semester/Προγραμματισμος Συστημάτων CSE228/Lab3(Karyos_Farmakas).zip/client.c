// STYLIANOS FARMAKAS 30833
// GEORGIOS KARYOS 30738

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/select.h>

#define BUFFER_SIZE 1024

static void print_prompt(void)
{
    printf("client> ");
    fflush(stdout);
}

int main(int argc, char *argv[])
{
    if (argc != 3)
    {
        fprintf(stderr, "Usage: %s <IP> <port>\n", argv[0]);
        return 1;
    }

    char *ip = argv[1];
    int port = atoi(argv[2]);
    if (port <= 0)
    {
        fprintf(stderr, "Invalid port\n");
        return 1;
    }

    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0)
    {
        perror("socket");
        return 1;
    }

    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);

    if (inet_pton(AF_INET, ip, &server_addr.sin_addr) <= 0)
    {
        perror("inet_pton");
        close(sockfd);
        return 1;
    }

    if (connect(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
    {
        perror("connect");
        close(sockfd);
        return 1;
    }

    print_prompt();

    while (1)
    {
        fd_set readfds;
        FD_ZERO(&readfds);
        FD_SET(STDIN_FILENO, &readfds);
        FD_SET(sockfd, &readfds);

        int maxfd = (sockfd > STDIN_FILENO) ? sockfd : STDIN_FILENO;

        if (select(maxfd + 1, &readfds, NULL, NULL, NULL) < 0)
        {
            perror("select");
            break;
        }

        if (FD_ISSET(STDIN_FILENO, &readfds))
        {
            char input[BUFFER_SIZE];
            if (fgets(input, sizeof(input), stdin) == NULL)
            {
                break;
            }

            input[strcspn(input, "\n")] = '\0';

            if (strcmp(input, "quit") == 0)
            {
                close(sockfd);
                return 0;
            }

            char message[BUFFER_SIZE];
            snprintf(message, sizeof(message), "[PID %d]: %s\n", getpid(), input);

            if (send(sockfd, message, strlen(message), 0) < 0)
            {
                perror("send");
                break;
            }

            print_prompt();
        }

        if (FD_ISSET(sockfd, &readfds))
        {
            char buffer[BUFFER_SIZE];
            int n = recv(sockfd, buffer, sizeof(buffer) - 1, 0);

            if (n <= 0)
            {
                printf("\nDisconnected from server.\n");
                break;
            }

            buffer[n] = '\0';
            printf("\n%s", buffer);
            print_prompt();
        }
    }

    close(sockfd);
    return 0;
}
