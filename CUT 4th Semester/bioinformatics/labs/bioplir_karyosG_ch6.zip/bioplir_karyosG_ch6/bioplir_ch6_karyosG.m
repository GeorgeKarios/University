load mit200;
figure, plot(tm,ecgsig), hold on
plot(tm(ann),ecgsig(ann),'ro'), xlabel('Seconds'); ylabel('Amplitude'),
title('Subject - MIT-BIH 200')

%Extract a QRS complex and plot the result with a dilated and translated 'sym4'
%wavelet for comparison.
qrsEx = ecgsig(4560:4810);
[mpdict,~,~,longs] = wmpdictionary(numel(qrsEx),'lstcpt',{{'sym4',3}});
figure, plot(qrsEx)
hold on, plot(2*circshift(mpdict(:,11),[-2 0]),'r')
axis tight
legend('QRS Complex','Sym4 Wavelet')
title('Comparison of Sym4 Wavelet and QRS Complex')

% Enhance the R peaks in the ECG waveform.
wt = modwt(ecgsig,5);
wtrec = zeros(size(wt));
wtrec(4:5,:) = wt(4:5,:);
y = imodwt(wtrec,'sym4');

%Employ a peak finding algorithm to identify the R peaks
y = abs(y).^2;
[qrspeaks,locs] = findpeaks(y,tm,'MinPeakHeight',0.35,...
'MinPeakDistance',0.150);

figure;
plot(tm,y), hold on, plot(locs,qrspeaks,'ro')
xlabel('Seconds')
title('R Peaks Localized by Wavelet Transform with Automatic Annotations')

%Automatic peak detection times are considered accurate if within 150 msec
plot(tm(ann),y(ann),'k*')
title('R peaks Localized by Wavelet Transform with Expert Annotations')

%Compare the values of tm(ann) and locs
figure, plot(tm,ecgsig,'k--'), hold on, plot(tm,y,'r','linewidth',1.5)
plot(tm,abs(ecgsig).^2,'b'), plot(tm(ann),ecgsig(ann),'ro','markerfacecolor',[1 0 0])
set(gca,'xlim',[10.2 12])
legend('Raw Data','Wavelet Reconstruction','Raw Data Squared','Location','SouthEast');
xlabel('Seconds')