.data
out_string: .asciiz "\nHello, World! -Karyos G.\n" #tipoma stin othoni
.text
.globl main
main:
    li $v0, 4
    la $a0, out_string
    syscall
    li $v0, 10
    syscall
	
	#Karyos G. - 30738