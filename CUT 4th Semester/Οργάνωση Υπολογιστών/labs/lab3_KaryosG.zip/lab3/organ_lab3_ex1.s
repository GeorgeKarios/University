.data
const5:   .float 5.0 
const9:   .float 9.0
const32:  .float 32.0 #statheres
.text
.globl f2c
f2c:
    lwc1 $f16, const5
    lwc1 $f18, const9
    div.s $f16, $f16, $f18

    lwc1 $f18, const32
    sub.s $f18, $f12, $f18
    mul.s $f0, $f16, $f18
    jr $ra
main:
    li $v0, 6   #eisagi float
    syscall     #timi se #f0
    mov.s $f12, $f0  #to stellei sto function
    jal f2c
    mov.s $f12, $f0  #tipoma apotelesm
    li $v0, 2
    syscall
    li $v0, 10
    syscall