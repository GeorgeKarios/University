# Karyos G.
.data
const: .float 273.15   #gia kelvin
.text
.globl main
main:
    li   $v0, 6    #diavazei vatmous kelsiou
    syscall      #apotelesma sto $f0
    lwc1 $f2, const  #f2=273.15
    add.s $f12, $f0, $f2 #f12=C+f2
    li   $v0, 2   #tiponei float
    syscall
    li   $v0, 10     #telos prog
    syscall