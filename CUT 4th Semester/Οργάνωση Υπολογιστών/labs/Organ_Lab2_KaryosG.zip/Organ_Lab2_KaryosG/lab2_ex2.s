.text
.globl main
main:
    li $v0, 5 #diavazei x
    syscall
    add $t0, $v0, $zero
    li $v0, 5 #diavazei y
    syscall
    add $t1, $v0, $zero
    add $a0, $t0, $zero #gia x+5
    jal add5
    add $t2, $v0, $zero
    add $a0, $t1, $zero #gia y-3
    jal sub3
    add $t3, $v0, $zero
    sub $a0, $t2, $t3 #r=a0=(x+5)-(y-3) /tipos proig askisis
    li $v0, 1
    syscall
    li $v0, 10
    syscall

add5:
    addi $sp, $sp, -4	#pointer 4 bytes kato
    sw   $ra, 0($sp)   #ra sto stack
    addi $v0, $a0, 5 #vo=ao+5
    lw   $ra, 0($sp) #ra piso apo stack
    addi $sp, $sp, 4 #pointer reset
    jr   $ra   #epistrefi stin main

sub3:
    addi $sp, $sp, -4
    sw   $ra, 0($sp)
    addi $v0, $a0, -3
    lw   $ra, 0($sp)
    addi $sp, $sp, 4
    jr   $ra  #epistrefei stin main