.text
.globl main
main:
    addi $v0, $zero, 5   #diavazei akeraio x
    syscall
    add  $t0, $v0, $zero    #t0=x
    addi $v0, $zero, 5    # diavazei y
    syscall
    add  $t1, $v0, $zero #t1=y
    addi $t2, $t0, 5  #ipologizei t2=x+5
    addi $t3, $t1, -3   #ipologizei t3=y-3
    sub  $a0, $t2, $t3      #a0=r=t2-t3
    addi $v0, $zero, 1   
    syscall       #tipoma r
    addi $v0, $zero, 10 
    syscall 