.data #karyos G
msg: .asciiz "athroisma aritmon einai "
newline: .asciiz "\n"
.text
.globl main

sum_fisikon_num:
    addi $sp, $sp, -4  #apothikeusi dieuthins gia epistrofi
    sw   $ra, 0($sp)
    addi $t0, $zero, 0  #sum=0
    addi $t1, $zero, 1    #i=1

loop:
    addi $t2, $a0, 1    #n+1
    beq  $t1, $t2, end    #an i==n+1 tote stamata
    add  $t0, $t0, $t1   #sum+=i
    addi $t1, $t1, 1    #i++
    j loop

end:
    add  $v0, $t0, $zero   #epistrofi sum
    lw   $ra, 0($sp)
    addi $sp, $sp, 4
    jr   $ra

main:
    addi $a0, $zero, 10   #n=10
    jal  sum_fisikon_num
    add  $t0, $v0, $zero 
    li $v0, 4       #tipoma 
    la $a0, msg
    syscall
    li $v0, 1      #tipoma apotelesm
    add $a0, $t0, $zero
    syscall
    li $v0, 4     
    la $a0, newline
    syscall
    li $v0, 10   #telos
    syscall