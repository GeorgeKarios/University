.data
newline: .asciiz "  Karyos G. HW1 Ex2: \n"
.text
.globl main
sum: #function gia recursion
    addi $sp, $sp, -8 #ap
    sw   $ra, 4($sp)
    sw   $a0, 0($sp)
    beq  $a0, $zero, base #an n=0 return 0
    addi $a0, $a0, -1
    jal  sum        #sum(n-1)
    lw   $t0, 0($sp)       
    add  $v0, $v0, $t0  #n+sum(n-1)
    j done

base:
    addi $v0, $zero, 0

done:
    lw   $ra, 4($sp)
    addi $sp, $sp, 8
    jr   $ra

main:
    addi $a0, $zero, 5  #sum(5)
    jal  sum
    add  $a0, $v0, $zero #tipoma apotelsm
    li   $v0, 1
    syscall
    li   $v0, 4
    la   $a0, newline
    syscall
    li   $v0, 10
    syscall