.data #ola ta minimata exodou
firstms: .asciiz "Vale 1o Arithmo:"
secondms: .asciiz "Vale 2o Arithmo:"
opms: .asciiz "Eisagogi Mathimatikis Praxis (+,-,*,/,%):"
resultms: .asciiz "apotelesma:"
errorms: .asciiz "Error: apagoreuetai i diaresi me 0\n"
againms: .asciiz "tha kaneis kai alli praxi?(1 for yes/0 for no):"
exitms: .asciiz "To Programma Klinei!"
nl: .asciiz "\n"
.text
.globl main

main:
start:
    li $v0, 4  #proto num
    la $a0, firstms
    syscall
    li $v0, 5
    syscall
    add $t0, $v0, $zero #apothikeuei proto num
    li $v0, 4 #2o num
    la $a0, secondms
    syscall
    li $v0, 5
    syscall
    add $t1, $v0, $zero #apothikeuei 2o num
    li $v0, 4 #rota gia tipo praxis (+-*/%)
    la $a0, opms
    syscall

readOp:
    li $v0, 12 # diavazei tipo praxis
    syscall
    add $t2, $v0, $zero
    addi $t3, $zero, 10
    beq $t2, $t3, readOp
    addi $t3, $zero, 43 #sikgrinei praxeis
    beq $t2, $t3, addOp
    addi $t3, $zero, 45
    beq $t2, $t3, subOp
    addi $t3, $zero, 42
    beq $t2, $t3, mulOp
    addi $t3, $zero, 47
    beq $t2, $t3, divOp
    addi $t3, $zero, 37
    beq $t2, $t3, modOp
    j askAgain

addOp: #prosthesi
    add $t4, $t0, $t1
    j printResult

subOp: #afairesi
    sub $t4, $t0, $t1
    j printResult

mulOp: #poll/smos
    mult $t0, $t1
    mflo $t4
    j printResult

divOp: #diairesi
    beq $t1, $zero, divError #elegxei an en 0
    div $t0, $t1
    mflo $t4
    j printResult

modOp: #mod
    beq $t1, $zero, divError #xanaelegxei an en 0
    div $t0, $t1
    mfhi $t4
    j printResult

divError: #an exei error 
    li $v0, 4
    la $a0, errorms
    syscall
    j askAgain

printResult: #tipoma
    li $v0, 4
    la $a0, resultms
    syscall
    li $v0, 1 #tipoma arithmous
    add $a0, $t4, $zero
    syscall
    li $v0, 4
    la $a0, nl #nea grammi
    syscall

askAgain: #thelei o user tz alli praxi??
    li $v0, 4
    la $a0, againms
    syscall
    li $v0, 5
    syscall
    addi $t3, $zero, 1
    beq $v0, $t3, start
    li $v0, 4 #bye bye
    la $a0, exitms
    syscall
    li $v0, 10
    syscall