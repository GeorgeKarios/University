package ex3_lab5;

import java.util.Scanner;
public class Ex3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter N: ");
        int N = sc.nextInt();
        int[][] arr = new int[N][N];
        fillRandomArray(arr);
        System.out.println("Initial array:");
        printArray(arr);
        int[][] rotated = rotate90Clockwise(arr);
        System.out.println("Array after 90 degree clockwise rotation:");
        printArray(rotated);
        sc.close();
    }

    public static void fillRandomArray(int[][] arr) {
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++)
                arr[i][j] = (int)(Math.random() * 10);
        }
    }
    public static int[][] rotate90Clockwise(int[][] arr) {
        int n = arr.length;
        int[][] rotated = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++)
                rotated[j][n - 1 - i] = arr[i][j];
        }
        return rotated;
    }
    public static void printArray(int[][] arr){
        for (int i = 0; i < arr.length; i++){
            for (int j = 0; j < arr[i].length; j++)
                System.out.print(arr[i][j] + " ");
            System.out.println();
        }
    }
}
