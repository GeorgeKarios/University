package ex2_lab5;

import java.util.Scanner;

public class Ex2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter array size N: ");
        int N = sc.nextInt();
        int[] arr = new int[N];
        fillRandomArray(arr);
        System.out.println("Initial array:");
        printArray(arr);
        makePositive(arr);
        System.out.println("Array after making all numbers positive:");
        printArray(arr);
        System.out.println("Array rotated 90 degrees clockwise:");
        rotate90Clockwise(arr);
        sc.close();
    }

    public static void fillRandomArray(int[] arr) {
        for (int i = 0; i < arr.length; i++)
            arr[i] = (int)(Math.random()*21) - 10;
    }
    public static void makePositive(int[] arr){
        for (int i = 0; i < arr.length; i++){
            if (arr[i] < 0)
                arr[i] = Math.abs(arr[i]);
        }
    }
    public static void rotate90Clockwise(int[] arr){
        for (int i = 0; i < arr.length; i++)
            System.out.println(arr[i]);
    }
    public static void printArray(int[] arr){
        for (int i = 0; i < arr.length; i++)
            System.out.print(arr[i] + " ");
        System.out.println();
    }
}