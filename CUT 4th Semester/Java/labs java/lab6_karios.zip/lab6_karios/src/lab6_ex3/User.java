package lab6_ex3;

public class User extends Person {
    private int borrowedBooks;

    public User(String name, int id, int borrowedBooks) {
        super(name, id);
        this.borrowedBooks = borrowedBooks;
    }

    public int getBorrowedBooks() {
        return borrowedBooks;
    }

    public void borrowBook() {
        borrowedBooks++;
    }

    public String toFileString() {
        return name + ";" + id + ";" + borrowedBooks;
    }

    public String toString() {
        return "User -> " + super.toString() + ", Borrowed books: " + borrowedBooks;
    }
}
