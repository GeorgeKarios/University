package lab6_ex3;

public class Author extends Person {
    private String nationality;

    public Author(String name, int id, String nationality) {
        super(name, id);
        this.nationality = nationality;
    }

    public String getNationality() {
        return nationality;
    }

    public String toString() {
        return "Author -> " + super.toString() + ", Nationality: " + nationality;
    }
}
