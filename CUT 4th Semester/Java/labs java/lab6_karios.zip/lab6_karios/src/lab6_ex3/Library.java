package lab6_ex3;

import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class Library {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        ArrayList<Book> books = new ArrayList<Book>();
        ArrayList<User> users = new ArrayList<User>();

        loadBooksFromFile(books);
        loadUsersFromFile(users);

        int choice;

        do {
            System.out.println("\n=== LIBRARY MENU ===");
            System.out.println("1. Show all books");
            System.out.println("2. Show all users");
            System.out.println("3. Add book");
            System.out.println("4. Add user");
            System.out.println("5. Delete book by ISBN");
            System.out.println("6. Delete user by ID");
            System.out.println("0. Exit");
            System.out.print("Choice: ");

            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    printBooks(books);
                    break;
                case 2:
                    printUsers(users);
                    break;
                case 3:
                    addBook(sc, books);
                    saveBooksToFile(books);
                    System.out.println("Book added and saved.");
                    break;
                case 4:
                    addUser(sc, users);
                    saveUsersToFile(users);
                    System.out.println("User added and saved.");
                    break;
                case 5:
                    try {
                        System.out.print("Give ISBN to delete: ");
                        String isbn = sc.nextLine();
                        deleteBookByISBN(books, isbn);
                        saveBooksToFile(books);
                        System.out.println("Book deleted and saved.");
                    } catch (BookNotFoundException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 6:
                    try {
                        System.out.print("Give user ID to delete: ");
                        int id = sc.nextInt();
                        sc.nextLine();
                        deleteUserByID(users, id);
                        saveUsersToFile(users);
                        System.out.println("User deleted and saved.");
                    } catch (UserNotFoundException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 0:
                    System.out.println("Program ended.");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }

        } while (choice != 0);

        sc.close();
    }

    public static void printBooks(ArrayList<Book> books) {
        System.out.println("\n=== BOOKS ===");
        for (Book b : books) {
            System.out.println(b);
        }
    }

    public static void printUsers(ArrayList<User> users) {
        System.out.println("\n=== USERS ===");
        for (User u : users) {
            System.out.println(u);
        }
    }

    public static void addBook(Scanner sc, ArrayList<Book> books) {
        System.out.print("Title: ");
        String title = sc.nextLine();

        System.out.print("Author name: ");
        String authorName = sc.nextLine();

        System.out.print("Author id: ");
        int authorId = sc.nextInt();
        sc.nextLine();

        System.out.print("Author nationality: ");
        String nationality = sc.nextLine();

        System.out.print("ISBN: ");
        String isbn = sc.nextLine();

        System.out.print("Pages: ");
        int pages = sc.nextInt();
        sc.nextLine();

        System.out.print("Category: ");
        String category = sc.nextLine();

        Author author = new Author(authorName, authorId, nationality);
        Book book = new Book(title, author, isbn, pages, category, false);
        books.add(book);
    }

    public static void addUser(Scanner sc, ArrayList<User> users) {
        System.out.print("Name: ");
        String name = sc.nextLine();

        System.out.print("ID: ");
        int id = sc.nextInt();
        sc.nextLine();

        User user = new User(name, id, 0);
        users.add(user);
    }

    public static void deleteBookByISBN(ArrayList<Book> books, String isbn) throws BookNotFoundException {
        for (int i = 0; i < books.size(); i++) {
            if (books.get(i).getIsbn().equals(isbn)) {
                books.remove(i);
                return;
            }
        }
        throw new BookNotFoundException("Book with ISBN " + isbn + " was not found.");
    }

    public static void deleteUserByID(ArrayList<User> users, int id) throws UserNotFoundException {
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getId() == id) {
                users.remove(i);
                return;
            }
        }
        throw new UserNotFoundException("User with ID " + id + " was not found.");
    }

    public static void loadBooksFromFile(ArrayList<Book> books) {
        Scanner input = null;

        try {
            File file = new File("books.txt");
            if (!file.exists()) {
                return;
            }
            input = new Scanner(new FileInputStream(file));
        } catch (FileNotFoundException e) {
            System.out.println("Error opening books.txt");
            return;
        }

        while (input.hasNextLine()) {
            String line = input.nextLine();
            String[] parts = line.split(";");

            if (parts.length == 8) {
                String title = parts[0];
                String authorName = parts[1];
                int authorId = Integer.parseInt(parts[2]);
                String nationality = parts[3];
                String isbn = parts[4];
                int pages = Integer.parseInt(parts[5]);
                String category = parts[6];
                boolean borrowed = Boolean.parseBoolean(parts[7]);

                Author author = new Author(authorName, authorId, nationality);
                Book book = new Book(title, author, isbn, pages, category, borrowed);
                books.add(book);
            }
        }

        input.close();
    }

    public static void loadUsersFromFile(ArrayList<User> users) {
        Scanner input = null;

        try {
            File file = new File("users.txt");
            if (!file.exists()) {
                return;
            }
            input = new Scanner(new FileInputStream(file));
        } catch (FileNotFoundException e) {
            System.out.println("Error opening users.txt");
            return;
        }

        while (input.hasNextLine()) {
            String line = input.nextLine();
            String[] parts = line.split(";");

            if (parts.length == 3) {
                String name = parts[0];
                int id = Integer.parseInt(parts[1]);
                int borrowedBooks = Integer.parseInt(parts[2]);

                User user = new User(name, id, borrowedBooks);
                users.add(user);
            }
        }

        input.close();
    }

    public static void saveBooksToFile(ArrayList<Book> books) {
        PrintWriter out = null;

        try {
            out = new PrintWriter(new FileOutputStream("books.txt"));
        } catch (FileNotFoundException e) {
            System.out.println("Error opening books.txt");
            System.exit(0);
        }

        for (Book b : books) {
            out.println(b.toFileString());
        }

        out.close();
    }

    public static void saveUsersToFile(ArrayList<User> users) {
        PrintWriter out = null;

        try {
            out = new PrintWriter(new FileOutputStream("users.txt"));
        } catch (FileNotFoundException e) {
            System.out.println("Error opening users.txt");
            System.exit(0);
        }

        for (User u : users) {
            out.println(u.toFileString());
        }

        out.close();
    }
}
