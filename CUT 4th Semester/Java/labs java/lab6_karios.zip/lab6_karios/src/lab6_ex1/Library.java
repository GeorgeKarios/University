package lab6_ex1;

import java.util.ArrayList;
import java.util.Scanner;
import java.io.PrintWriter;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;

public class Library {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        ArrayList<Book> books = new ArrayList<Book>();
        ArrayList<User> users = new ArrayList<User>();

        System.out.println("=== ENTER 4 BOOKS ===");
        for (int i = 0; i < 4; i++) {
            System.out.println("Book " + (i + 1));

            System.out.print("Title: ");
            String title = sc.nextLine();

            System.out.print("Author name: ");
            String authorName = sc.nextLine();

            System.out.print("Author id: ");
            int authorId = sc.nextInt();
            sc.nextLine();

            System.out.print("Author nationality: ");
            String nationality = sc.nextLine();

            System.out.print("ISBN: ");
            String isbn = sc.nextLine();

            System.out.print("Pages: ");
            int pages = sc.nextInt();
            sc.nextLine();

            System.out.print("Category: ");
            String category = sc.nextLine();

            Author author = new Author(authorName, authorId, nationality);
            Book book = new Book(title, author, isbn, pages, category);
            books.add(book);

            System.out.println();
        }

        System.out.println("=== ENTER 4 USERS ===");
        for (int i = 0; i < 4; i++) {
            System.out.println("User " + (i + 1));

            System.out.print("Name: ");
            String userName = sc.nextLine();

            System.out.print("ID: ");
            int userId = sc.nextInt();
            sc.nextLine();

            User user = new User(userName, userId);
            users.add(user);

            System.out.println();
        }

        if (books.size() > 0 && users.size() > 0) {
            users.get(0).borrowBook();
        }

        saveBooksToFile(books);
        saveUsersToFile(users);

        System.out.println("Data saved to files successfully.");

        sc.close();
    }

    public static void saveBooksToFile(ArrayList<Book> books) {
        PrintWriter out = null;

        try {
            out = new PrintWriter(new FileOutputStream("books.txt"));
        } catch (FileNotFoundException e) {
            System.out.println("Error opening books.txt");
            System.exit(0);
        }

        for (Book b : books) {
            out.println(b);
        }

        out.close();
    }

    public static void saveUsersToFile(ArrayList<User> users) {
        PrintWriter out = null;

        try {
            out = new PrintWriter(new FileOutputStream("users.txt"));
        } catch (FileNotFoundException e) {
            System.out.println("Error opening users.txt");
            System.exit(0);
        }

        for (User u : users) {
            out.println(u);
        }

        out.close();
    }
}
