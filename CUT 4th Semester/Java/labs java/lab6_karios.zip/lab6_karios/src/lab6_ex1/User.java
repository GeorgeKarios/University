package lab6_ex1;

public class User extends Person {
    private int borrowedBooks;

    public User(String name, int id) {
        super(name, id);
        borrowedBooks = 0;
    }

    public void borrowBook() {
        borrowedBooks++;
    }

    public String toString() {
        return "User -> " + super.toString() + ", Borrowed books: " + borrowedBooks;
    }
}
