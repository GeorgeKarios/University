package lab6_ex1;

public class Book {
    private String title;
    private Author author;
    private String isbn;
    private int pages;
    private String category;
    private boolean borrowed;

    public Book(String title, Author author, String isbn, int pages, String category) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.pages = pages;
        this.category = category;
        borrowed = false;
    }

    public String toString() {
        return "Book -> Title: " + title +  ", Author: " + author.getName() + ", ISBN: " + isbn + ", Pages: " + pages + ", Category: " + category + ", Borrowed: " + borrowed;
    }
}