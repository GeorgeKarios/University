package lab6_ex2;

public class Book {
    private String title;
    private Author author;
    private String isbn;
    private int pages;
    private String category;
    private boolean borrowed;

    public Book(String title, Author author, String isbn, int pages, String category, boolean borrowed) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.pages = pages;
        this.category = category;
        this.borrowed = borrowed;
    }

    public String getTitle() {
        return title;
    }

    public Author getAuthor() {
        return author;
    }

    public String getIsbn() {
        return isbn;
    }

    public int getPages() {
        return pages;
    }

    public String getCategory() {
        return category;
    }

    public boolean isBorrowed() {
        return borrowed;
    }

    public String toFileString() {
        return title + ";" +
               author.getName() + ";" +
               author.getId() + ";" +
               author.getNationality() + ";" +
               isbn + ";" +
               pages + ";" +
               category + ";" +
               borrowed;
    }

    public String toString() {
        return "Book -> Title: " + title +
               ", Author: " + author.getName() +
               ", ISBN: " + isbn +
               ", Pages: " + pages +
               ", Category: " + category +
               ", Borrowed: " + borrowed;
    }
}
