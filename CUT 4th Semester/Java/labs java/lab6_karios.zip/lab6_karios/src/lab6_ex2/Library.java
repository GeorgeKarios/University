package lab6_ex2;

import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class Library {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        ArrayList<Book> books = new ArrayList<Book>();
        ArrayList<User> users = new ArrayList<User>();

        loadBooksFromFile(books);
        loadUsersFromFile(users);

        System.out.println("=== BOOKS LOADED FROM FILE ===");
        for (Book b : books) {
            System.out.println(b);
        }

        System.out.println();
        System.out.println("=== USERS LOADED FROM FILE ===");
        for (User u : users) {
            System.out.println(u);
        }

        System.out.println();
        System.out.println("=== ADD 3 MORE BOOKS ===");
        for (int i = 0; i < 3; i++) {
            System.out.println("Book " + (i + 1));

            System.out.print("Title: ");
            String title = sc.nextLine();

            System.out.print("Author name: ");
            String authorName = sc.nextLine();

            System.out.print("Author id: ");
            int authorId = sc.nextInt();
            sc.nextLine();

            System.out.print("Author nationality: ");
            String nationality = sc.nextLine();

            System.out.print("ISBN: ");
            String isbn = sc.nextLine();

            System.out.print("Pages: ");
            int pages = sc.nextInt();
            sc.nextLine();

            System.out.print("Category: ");
            String category = sc.nextLine();

            Author author = new Author(authorName, authorId, nationality);
            Book book = new Book(title, author, isbn, pages, category, false);
            books.add(book);

            System.out.println();
        }

        System.out.println("=== ADD 3 MORE USERS ===");
        for (int i = 0; i < 3; i++) {
            System.out.println("User " + (i + 1));

            System.out.print("Name: ");
            String name = sc.nextLine();

            System.out.print("ID: ");
            int id = sc.nextInt();
            sc.nextLine();

            User user = new User(name, id, 0);
            users.add(user);

            System.out.println();
        }

        saveBooksToFile(books);
        saveUsersToFile(users);

        System.out.println("=== UPDATED BOOKS ===");
        for (Book b : books) {
            System.out.println(b);
        }

        System.out.println();
        System.out.println("=== UPDATED USERS ===");
        for (User u : users) {
            System.out.println(u);
        }

        System.out.println();
        System.out.println("Files updated successfully.");

        sc.close();
    }

    public static void loadBooksFromFile(ArrayList<Book> books) {
        Scanner input = null;

        try {
            File file = new File("books.txt");
            if (!file.exists()) {
                return;
            }
            input = new Scanner(new FileInputStream(file));
        } catch (FileNotFoundException e) {
            System.out.println("Error opening books.txt");
            return;
        }

        while (input.hasNextLine()) {
            String line = input.nextLine();
            String[] parts = line.split(";");

            if (parts.length == 8) {
                String title = parts[0];
                String authorName = parts[1];
                int authorId = Integer.parseInt(parts[2]);
                String nationality = parts[3];
                String isbn = parts[4];
                int pages = Integer.parseInt(parts[5]);
                String category = parts[6];
                boolean borrowed = Boolean.parseBoolean(parts[7]);

                Author author = new Author(authorName, authorId, nationality);
                Book book = new Book(title, author, isbn, pages, category, borrowed);
                books.add(book);
            }
        }

        input.close();
    }

    public static void loadUsersFromFile(ArrayList<User> users) {
        Scanner input = null;

        try {
            File file = new File("users.txt");
            if (!file.exists()) {
                return;
            }
            input = new Scanner(new FileInputStream(file));
        } catch (FileNotFoundException e) {
            System.out.println("Error opening users.txt");
            return;
        }

        while (input.hasNextLine()) {
            String line = input.nextLine();
            String[] parts = line.split(";");

            if (parts.length == 3) {
                String name = parts[0];
                int id = Integer.parseInt(parts[1]);
                int borrowedBooks = Integer.parseInt(parts[2]);

                User user = new User(name, id, borrowedBooks);
                users.add(user);
            }
        }

        input.close();
    }

    public static void saveBooksToFile(ArrayList<Book> books) {
        PrintWriter out = null;

        try {
            out = new PrintWriter(new FileOutputStream("books.txt"));
        } catch (FileNotFoundException e) {
            System.out.println("Error opening books.txt");
            System.exit(0);
        }

        for (Book b : books) {
            out.println(b.toFileString());
        }

        out.close();
    }

    public static void saveUsersToFile(ArrayList<User> users) {
        PrintWriter out = null;

        try {
            out = new PrintWriter(new FileOutputStream("users.txt"));
        } catch (FileNotFoundException e) {
            System.out.println("Error opening users.txt");
            System.exit(0);
        }

        for (User u : users) {
            out.println(u.toFileString());
        }

        out.close();
    }
}
